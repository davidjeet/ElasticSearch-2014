﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtResults.Text = "";
            string uri = txtURI.Text;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            txtResults.Text += "Content length is " + response.ContentLength + Environment.NewLine ;
            txtResults.Text += "Content type is {0}" + response.ContentType + Environment.NewLine;

            // Get the stream associated with the response.
            Stream receiveStream = response.GetResponseStream();

            // Pipes the stream to a higher level stream reader with the required encoding format. 
            StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);

             txtResults.Text +=  "Response stream received." + Environment.NewLine ;
             txtResults.Text +=  readStream.ReadToEnd();

            response.Close();
            readStream.Close();
        }
    }
}
