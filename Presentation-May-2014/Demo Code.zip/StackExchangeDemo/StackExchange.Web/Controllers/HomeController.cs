﻿using MongoDB.Driver;
using MongoDB.Driver.Linq;
using StackExchangeModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Diagnostics;
using Nest;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace StackExchange.Web.Controllers
{
    public class HomeController : Controller
    {
        private static MongoClient mongoClient;
        private static MongoServer mongoServer;
        private static MongoDatabase mongoDatabase;
        private static MongoCollection<Post> mongoCollection;
        private const string INDEX = "stackexchange";
        private const string INDEXTYPE = "posts";

        public HomeController()
        {
            mongoClient = new MongoClient("mongodb://localhost:27017");
            mongoServer = mongoClient.GetServer();
            mongoDatabase = mongoServer.GetDatabase("stackexchange");
            ViewBag.Message = "";
        }
        
        public ActionResult Index()
        {
            mongoCollection = mongoDatabase.GetCollection<Post>(INDEXTYPE);
            var vm = mongoCollection.AsQueryable().OrderByDescending(x=>x.CreationDate).Take(10);
            return View(vm);
        }

        public ActionResult ReIndex()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            mongoCollection = mongoDatabase.GetCollection<Post>("posts");
            foreach (var post in mongoCollection.FindAll())
            {
                ElasticClient.Index(post, INDEX, INDEXTYPE, post.Id);
            }

            sw.Stop();
            var result = string.Format("Time to re-index elasticsearch took: {0}.{1} seconds", sw.Elapsed.Seconds, sw.Elapsed.Milliseconds);
            ViewBag.Message = result;
            Debug.WriteLine(result);

            return View();
        }

        [HttpPost]
        public ActionResult FullTextSearch(string q, bool addHighlights = false)
        {

            #region Elasticsearch query

            var result = ElasticClient.Search<Post>(x => x.Query(query
                                                => query.Fuzzy(fz
                                                    => fz.OnField(f
                                                        => f.Title).Value(q)
                                                    .MinSimilarity(0.5) // choose a value between 0-1                                                    
                                                    .PrefixLength(2) // first two characters are not considered
                                                   ))
                                                
                .Highlight(h => h
                    .OnFields(f => f
                    .OnField(e => e.Body)
                    .PreTags("<b><em><font color='red'>")
                    .PostTags("</font></em></b>")
                    ))
                
    
                .Take(5)

              );

            #endregion

            #region Viewmodel manipulation

            ViewBag.Message = string.Format("<h4>Your search results returned {0}/{1} results: </h4>", result.Documents.Count(), result.Total);


            if (result.Total == 0)
            {

                return View("Index", new List<Post>());
            }

            List<Post> posts = new List<Post>();
            if (addHighlights)
            {
                foreach (var doc in result.Highlights.Values)
                {
                    string id ="";
                    StringBuilder fragments = new StringBuilder();
                    foreach (var key in doc.Keys)
                    {
                        Highlight item = doc[key];
                        id = item.DocumentId;
                        foreach(string highlight in item.Highlights)
                        {
                            fragments.AppendFormat("<blockquote>{0}</blockquote>", highlight);
                        }

            
                    }
                    var newPost = result.Documents.SingleOrDefault(x => x.Id.ToString() == id);
                    newPost.Body = fragments.ToString();
                    posts.Add(newPost);
                }
            }
            else
            {
                var postIds = result.Documents.Select(doc => doc.Id).ToList();
                mongoCollection = mongoDatabase.GetCollection<Post>("posts");
                posts = mongoCollection.AsQueryable().Where(p => p.Id.In( postIds )).ToList(); 
            }

            #endregion

            return View("Index", posts);
        }

        #region static property helper

        private static ElasticClient ElasticClient
        {
            get
            {

                var setting = new ConnectionSettings(new Uri("http://localhost:9200"));
                setting.SetDefaultIndex(INDEX);
                return new ElasticClient(setting);
            }
        }

        #endregion
    }
}